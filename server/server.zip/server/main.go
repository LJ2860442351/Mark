package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"html/template"
	"io"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"runtime"
	"strings"
)

type page struct {
	Title string //标题
	Body  []byte //身体
}

type data struct {
	Name     string //名字
	Password string //密码
}
type ret struct {
	Code  int
	Param string
	Msg   string
	Data  []data
}

//声明日志变量
var (
	logFileName = flag.String("log", "mark.log", "Log file name")
)
var tmplView = template.Must(template.New("test").ParseFiles("src/base.html", "src/test.html", "src/main.html"))
var tmplEdit = template.Must(template.New("edit").ParseFiles("src/base.html", "src/edit.html", "src/main.html"))
var tmplContent = template.Must(template.New("content").ParseFiles("src/base.html", "src/content.html", "src/main.html"))

func (p *page) save() error {
	f := p.Title + ".txt"
	return ioutil.WriteFile(f, p.Body, 0600)
}

func load(title string) (*page, error) {
	f := title + ".txt"
	body, err := ioutil.ReadFile(f)
	if err != nil {
		return nil, err
	}
	return &page{Title: title, Body: body}, nil
}

func view(w http.ResponseWriter, r *http.Request) {

	title := r.URL.Path[len("/test/"):]
	p, _ := load(title)

	tmplView.ExecuteTemplate(w, "base", p)
	//t, _ := template.ParseFiles("test.html")
	//t.Execute(w, p)
}

func edit(w http.ResponseWriter, r *http.Request) {
	title := r.URL.Path[len("/edit/"):]
	p, _ := load(title)

	tmplEdit.ExecuteTemplate(w, "base", p)
	//t, _ := template.ParseFiles("edit.html")
	//t.Execute(w, p)
}

func content(w http.ResponseWriter, r *http.Request) {
	title := r.URL.Path[len("/content/"):]
	p, _ := load(title)

	tmplContent.ExecuteTemplate(w, "base", p)

}

func save(w http.ResponseWriter, r *http.Request) {
	title := r.URL.Path[len("/save/"):]
	body := r.FormValue("body")
	p := &page{Title: title, Body: []byte(body)}
	p.save()
	http.Redirect(w, r, "/test/"+title, http.StatusFound)
}

type myHandler struct{}

func (*myHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	w.Write([]byte("hello liujian,the request URL is :" + r.URL.String()))
}
func sayHello(w http.ResponseWriter, r *http.Request) {
	// w.Write([]byte("Bye bye,see you next time"))
	w.Write([]byte("hello liujian,the request URL is :" + r.URL.String()))

}

//重定向支持
func redirect(w http.ResponseWriter, r *http.Request) {
	title := "localhost:8010"
	http.Redirect(w, r, title, http.StatusFound)
}

//返回json信息
func getInfo(w http.ResponseWriter, req *http.Request) {
	data := data{Name: "liujian", Password: "123"}

	ret := new(ret)
	id := req.FormValue("id")
	//id := req.PostFormValue('id')
	ret.Code = 0
	ret.Param = id
	ret.Msg = "success"
	ret.Data = append(ret.Data, data)
	retJSON, _ := json.Marshal(ret)
	io.WriteString(w, string(retJSON))
}

//打印其他的头部信息
func sayhelloName(w http.ResponseWriter, r *http.Request) {
	r.ParseForm()       //解析参数，默认是不会解析的
	fmt.Println(r.Form) //这些信息是输出到服务器端的打印信息
	fmt.Println("path:", r.URL.Path)
	fmt.Println("scheme:", r.URL.Scheme)
	fmt.Println(r.Form["url_long"])
	for k, v := range r.Form {
		fmt.Println("key:", k)
		fmt.Println("val:", strings.Join(v, ""))
	}
	fmt.Fprintf(w, "Hello Mark!") //这个写入到w的是输出到客户端的
}

//获取当前目录
func files() {
	files, err := ioutil.ReadDir(".")
	if err != nil {
		log.Fatal(err)
	}

	for _, file := range files {
		fmt.Println(file.Name())
	}
}

//main 函数
func main() {
	//mux实现了基本的路由
	mux := http.NewServeMux()
	mux.Handle("/", &myHandler{})
	mux.HandleFunc("/hello", sayHello)
	mux.HandleFunc("/redirect", redirect)

	//基本配置
	port := flag.String("p", "8010", "port")
	dir := flag.String("d", ".", "dir")
	//解析参数
	flag.Parse()

	//调用sayhelloName函数
	// http.HandleFunc("/",sayhelloName)
	//设置主页要访问的路由
	http.Handle("/", http.FileServer(http.Dir(*dir)))
	http.HandleFunc("/hello", sayHello)
	http.HandleFunc("/www/redirect", redirect)
	http.HandleFunc("/getInfo", getInfo)

	http.Handle("/static/", http.StripPrefix("/static/", http.FileServer(http.Dir("static"))))
	http.HandleFunc("/test/", view)
	http.HandleFunc("/edit/", edit)
	http.HandleFunc("/content/", content)
	http.HandleFunc("/save/", save)

	//服务器端的日志打印面板
	log.Printf("start successfully!!!\n")
	log.Printf("Mark webserver is starting........port:%s\n", *port)
	log.Printf("Log print is Server %s on Http:%s\n", *dir, *port)

	runtime.GOMAXPROCS(runtime.NumCPU())
	flag.Parse()

	//set logfile Stdout
	logFile, logErr := os.OpenFile(*logFileName, os.O_CREATE|os.O_RDWR|os.O_APPEND, 0666)
	if logErr != nil {
		fmt.Println("Fail to find", *logFile, "cServer start Failed")
		os.Exit(1)
	}
	log.SetOutput(logFile)
	log.SetFlags(log.Ldate | log.Ltime | log.Lshortfile)

	//write log
	log.Printf("Server abort! Cause:%v \n", "mark log file")
	log.Printf("start successfully!!!\n")
	log.Printf("Mark webserver is starting........port:%s\n", *port)
	log.Printf("Log print is Server %s on Http:%s\n", *dir, *port)

	//运行主函数 主目录的函数功能
	log.Fatal(http.ListenAndServe(":"+*port, nil))
	//通过url访问的函数 监听本地的路由
	log.Fatal(http.ListenAndServe(":"+*port, mux))

}
