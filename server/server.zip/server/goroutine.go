package main

import (
	"fmt"
	"runtime"
	"sync"
)

const (
	i = iota + 1
	j = iota * 1000
	k = iota * 10000
	l = iota * 100000
)

func main() {

	// 分配逻辑处理器
	runtime.GOMAXPROCS(1)

	//wg贝用来程序等待完成
	//添加2个
	var wg sync.WaitGroup
	wg.Add(1)
	fmt.Println("Start Goroutines")
	//声明匿名函数来创建并发
	go func() {
		defer wg.Done()
		// for count := 0; count < 3; count++ {
		fmt.Println("Completed  ", i, "requests")
		fmt.Println("Completed  ", j, "requests")
		fmt.Println("Completed  ", k, "requests")
		fmt.Println("Completed  ", l, "requests")
		// for char := 'a'; char < 'a'+26; char++ {
		// 	fmt.Printf("%c ", char)
		// }
		fmt.Println()
		// }
	}()

	fmt.Println("Waiting To Finish")
	wg.Wait()
	fmt.Println("\nTerminating Program")
}
