package main

import (
    "fmt"
    "math"
)

func main(){
    fmt.Println(math.Round(3.4))
    fmt.Println(math.Round(4.5))
    fmt.Println(math.Round(-3.4))
    fmt.Println(math.Round(-4.5))
    fmt.Println(math.Abs(-5.4))
}